import pandas as pd
import numpy as np

df = pd.read_csv("athlete_events.csv")
# 1

ejercicio_1 = df.shape

# 2

ejercicio_2 = df.loc[:,"Games"].value_counts().shape

# 3


ejercicio_3 = [df.loc[:,"Season"].value_counts()["Summer"]/df.loc[:,"Season"].value_counts().sum(), 
df.loc[:,"Season"].value_counts()["Winter"]/df.loc[:,"Season"].value_counts().sum()]


# 4

fecha_primera_competencia = df.loc[:,"Year"].min()
season_summer = df[df["Season"]== "Summer"]
ejercicio_4 = season_summer[season_summer["Year"] == fecha_primera_competencia]["City"].unique() 


# 5

season_winter = df[df["Season"]=="Winter"]
fecha_primera_competencia_winter = season_winter.loc[:,"Year"].min()
ejercicio_5 = season_winter[season_winter["Year"]==fecha_primera_competencia_winter]["City"].unique()

# 6

ejercicio_6= df["Team"].value_counts().head(10)


# 7

gold = df[df["Medal"].isnull() == False].loc[:,"Medal"].value_counts()["Gold"]/df[df["Medal"].isnull() == False].shape[0]
silver = df[df["Medal"].isnull() == False].loc[:,"Medal"].value_counts()["Silver"]/df[df["Medal"].isnull() == False].shape[0]
bronze = df[df["Medal"].isnull() == False].loc[:,"Medal"].value_counts()["Bronze"]/df[df["Medal"].isnull() == False].shape[0]
ejercicio_7 = [gold, silver, bronze]


# 8

ejercicio_8 = df[df["Year"] == fecha_primera_competencia]["NOC"].unique()
